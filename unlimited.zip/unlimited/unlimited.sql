-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2021 at 04:40 PM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `unlimited`
--

-- --------------------------------------------------------

--
-- Table structure for table `adddata`
--

CREATE TABLE `adddata` (
  `id` int(11) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `pprice` varchar(50) NOT NULL,
  `pdesc` varchar(500) NOT NULL,
  `cate` varchar(20) NOT NULL,
  `code` varchar(50) NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adddata`
--

INSERT INTO `adddata` (`id`, `pname`, `pprice`, `pdesc`, `cate`, `code`, `image`) VALUES
(10, 'saree', '300', 'dress', 'Clothing', 'dress01', 'images/dress2.jpg\r\n'),
(11, 'Dress_3', '300', 'saree', 'Clothing', 'dress02', 'images/dress3.jpg'),
(12, 'Dress_04', '400', 'saree', 'Clothing', 'dress02', ' images/dress4.jpg'),
(13, 'Dress_1', '200', 'dress', 'clothngs', 'dress01', ' images/dress1.jpg'),
(14, 'shoes_1', '500', 'shoes', 'Shoes', 'shoe01', ' images/shoe1.jpg'),
(15, 'shoe_02', '600', 'shoes', 'Shoes', 'shoe01', 'images/shoe2.jpg'),
(16, 'shoe_03', '700', 'shoes', 'Shoes', 'shoe01', 'images/shoe3.jpg'),
(17, 'shoe_04', '1000', 'shoes', 'Shoes', 'shoe01', 'images/shoe4.jpg'),
(18, 'Iphone', '10000', 'Iphone 11pro', 'Mobiles', 'mob01', ' images/mob2.jpg'),
(19, 'Oneplus', '15000', 'oneplus 8 pro', 'Mobiles', 'mob01', 'images/mob1.jpg'),
(20, 'Samsung S21', '100000', 'samsung s21 ultra', 'Mobiles', 'mob01', 'images/mob3.jpg'),
(21, 'Lumia 1020', '50000', 'Nokia lumia 1020 with biggest camera ever', 'Mobiles', 'mob01', 'images/mob4.jpg'),
(22, 'Iphone', '50000', 'iphone 12 pro', 'Mobiles', 'mob01', ' images/mob5.jpg'),
(23, 'iphone', '25000', 'iphone Xs', 'Mobiles', 'mob01', ' images/mob6.jpg'),
(24, 'Dress_5', '600', 'ghagra', 'Clothing', 'dress03', 'images/dress5.jpg'),
(25, 'Dress_6', '700', 'ghagra', 'Clothing', 'dress03', 'images/dress6.jpg'),
(26, 'Dress_7', '1000', 'ghagra', 'Clothing', 'dress03', 'images/dress7.jpg'),
(27, 'shoe_05', '1000', 'black nike shoes', 'Shoes', 'shoe04', 'images/shoe5.jpg'),
(28, 'shoe_06', '10000', 'black futuristic shoes', 'Shoes', 'shoe04', 'images/shoe6.jpg'),
(29, 'shoe_07', '10000', 'barefoot shoes', 'Shoes', 'shoe04', 'images/shoe7.jpg'),
(30, 'belts', '200', 'leather', 'Mens', 'men01', ' images/men1.jpg'),
(31, 'Jacket', '500', 'jacket', 'Mens', 'men01', ' images/men2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `uname`, `pass`) VALUES
(1, 'admin', '123');

-- --------------------------------------------------------

--
-- Table structure for table `card`
--

CREATE TABLE `card` (
  `id` int(20) NOT NULL,
  `cardno` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `cvv` varchar(50) NOT NULL,
  `expiry` varchar(50) NOT NULL,
  `uname` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `card`
--

INSERT INTO `card` (`id`, `cardno`, `name`, `cvv`, `expiry`, `uname`) VALUES
(1, 'sasa', 'sasa', '034a', '22/55', ''),
(4, '123', 'sasank', '025', '212125', ''),
(5, '2587', 'sarath', '034', '02/20', 'sasank@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cid` int(11) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `cquantity` varchar(50) NOT NULL,
  `cprice` varchar(50) NOT NULL,
  `cfinal_price` varchar(50) NOT NULL,
  `ccode` varchar(50) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cid`, `cname`, `cquantity`, `cprice`, `cfinal_price`, `ccode`, `order_id`, `uname`, `status`) VALUES
(54, ' belts', '1', '$ 200', '$ 200.00', 'men01', '6801', '', 'order placed'),
(55, ' shoe_05', '3', '$ 1000', '$ 3,000.00', 'shoe04', '6801', '', 'order placed'),
(58, ' belts', '1', '$ 200', '$ 200.00', 'men01', '7503', 'sasank@gmail.com', 'order placed'),
(59, ' shoe_05', '4', '$ 1000', '$ 4,000.00', 'shoe04', '7503', 'sasank@gmail.com', 'order placed'),
(60, ' shoes_1', '1', '$ 500', '$ 500.00', 'shoe01', '9537', 'sasank@gmail.com', 'order placed'),
(65, ' Iphone', '1', '$ 10000', '$ 10,000.00', 'mob01', '2423', 'sasank@gmail.com', 'order placed'),
(66, ' Iphone', '1', '$ 10000', '$ 10,000.00', 'mob01', '5187', 'sasank@gmail.com', 'order placed'),
(67, ' Dress_3', '1', '$ 300', '$ 300.00', 'dress02', '6987', 'sasank@gmail.com', 'order placed'),
(68, ' Iphone', '1', '$ 10000', '$ 10,000.00', 'mob01', '6624', 'sasank@gmail.com', 'order placed'),
(69, ' Dress_3', '1', '$ 300', '$ 300.00', 'dress02', '1946', 'sasank@gmail.com', 'order placed');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `category` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category`) VALUES
(1, 'Mobiles'),
(2, 'Clothings'),
(3, 'Shoes'),
(4, 'Mens');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `pass` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `name`, `email`, `phone`, `address`, `pass`) VALUES
(1, 'sasank', 'sasank@gmail.com', '123', 'bza\r\n     ', '123'),
(2, 'sasank', 'sasank@gmail.com', '123', 'bza', '123'),
(3, 'stark', 'stark@tony.com', '357', 'ny', '123');

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--

CREATE TABLE `tblproduct` (
  `id` int(8) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblproduct`
--

INSERT INTO `tblproduct` (`id`, `name`, `code`, `image`, `price`) VALUES
(1, 'MSI GF63 Thin Core i7 9th Gen', 'MSI4353', 'product-images/msi-laptop.jpeg', 1500.00),
(2, 'WD 1.5 TB Wired External Hard Disk Drive  (Black)', 'WD091', 'product-images/external-hardidisk.jpeg', 50.00),
(3, 'VERTIGO Running Shoes For Men  (Black)', 'LOTTO215', 'product-images/lotto-shoes.jpeg', 10.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adddata`
--
ALTER TABLE `adddata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `card`
--
ALTER TABLE `card`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblproduct`
--
ALTER TABLE `tblproduct`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_code` (`code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adddata`
--
ALTER TABLE `adddata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `card`
--
ALTER TABLE `card`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblproduct`
--
ALTER TABLE `tblproduct`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
