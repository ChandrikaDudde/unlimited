<?php
session_start();

 
include 'config.php';

$id = $_POST['id'];
$pname = $_POST['pname'];
$pprice = $_POST['pprice'];
$pdesc = $_POST['pdesc'];

 


$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Unable to connect to database! Please try again later.");



if (@$_POST['submit']) {
    //storing all necessary data into the respective variables.
    $file = $_FILES['file'];
    $file_name = $file['name'];
    $file_type = $file['type'];
    $file_size = $file['size'];
    $file_path = $file['tmp_name'];

    //Restriction to the image. You can upload any types of file for example video file, mp3 file, .doc or .pdf just mention here in OR condition. 

    //if($file_name!="" && ($file_type="image/jpeg"||$file_type="image/png"||$file_type="image/gif")&& $file_size<=614400)

    if (move_uploaded_file($file_path, 'images/' . $file_name)) //"images" is just a folder name here we will load the file.

        $query = "UPDATE adddata SET pname='$pname', pprice='$pprice', pdesc='$pdesc', image='$target_path' WHERE id='$id' ";

        //$sql = "UPDATE MyGuests SET lastname='Doe' WHERE id=2";

        if ($conn->query($query) === TRUE) {
            header('Location:admin_home.php');
            echo "Error: " . $sql . "<br>" . $conn->error;
            echo "Error updating record: " . $conn->error;
            echo "<br>";
          } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
          }
      $conn->close();
}
