<?php
include "config.php";

$id = $_POST['id'];
$pname = $_POST['pname'];
$pprice = $_POST['pprice'];
$pdesc = $_POST['pdesc'];



// echo $title;
// echo $cate;
// echo $desc;

// $target_path = "images/";

// $target_path = $target_path . basename($_FILES['file']['name']);

// if (move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {

  $sql = "UPDATE adddata SET pname='$pname', pprice='$pprice', pdesc='$pdesc' WHERE id='$id'";

  if ($conn->query($sql) === TRUE) {
    // echo "New record created successfully";
    header('Location:admin_home.php');
    echo "Error: " . $sql . "<br>" . $conn->error;
    echo "Error updating record: " . $conn->error;
    echo "<br>";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }

  $conn->close();
// }
