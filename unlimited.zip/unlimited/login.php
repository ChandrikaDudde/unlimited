<?php
session_start();

include 'config.php';

$uname = $_POST['uname'];
$pass = $_POST['pass'];




$sql = "SELECT email,pass FROM register where email='$uname' and pass='$pass' ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

  // fetch data
  $uid = mysqli_fetch_array($result);

  //    $_SESSION['id'] = $uid['id'];
  $_SESSION["uname"] = $uname;
  


  header('Location:home.php');
} else {

  echo "Invalid Details";
  // echo "<script>
  // alert('Invalid Details')</script>";
  // header('Location:index.html');
}
$conn->close();