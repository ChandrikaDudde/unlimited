<?php
session_start();
include "config.php";
$uname = $_SESSION['uname'];


if (isset($_POST['checkout_submit'])) {

    $cname = $_POST['cname'];
    $ccode = $_POST['ccode'];
    $cquantity = $_POST['cquantity'];
    $cprice = $_POST['cprice'];
    $cfinalprice = $_POST['cfinalprice'];
 

    $o = rand(1000, 9999);

    for ($i = 0; $i < count($cname); $i++) {

        //  echo $data."-". $ccode[$index];

        $c_name = $cname[$i];
        $c_code = $ccode[$i];
        $c_quantity = $cquantity[$i];
        $c_price = $cprice[$i];
        $c_finalprice = $cfinalprice[$i];
         
        // echo $cname;
        // echo $ccode;
        // echo $cquantity;
        // echo $cprice;
        // echo $cfinalprice;


        $sql = "INSERT INTO cart (cname, cquantity, cprice, cfinal_price, ccode, order_id, uname, status)
        VALUES ('$c_name', '$c_quantity','$c_price','$c_finalprice','$c_code', '$o', '$uname', 'order placed')";


        // $sql = "INSERT INTO cart (cname, cquantity, cprice, cfinal_price, ccode)
        // VALUES ('?', '?','?','?','?')";


        $query_run = mysqli_query($conn, $sql);
    }

    if ($query_run) {
        // echo "Error: " . $sql . "<br>" . $conn->error;
        // echo "<!-- line ", __LINE__, " value is ", gettype($variable), " -->";
         header('Location:payment.php');
        // exit(0);
    } else {

        $_SESSION['status'] = "data not inserted successfully";
        header('Location:home.php');
        exit(0);
    }
}



 
// $sql = "INSERT INTO cart (cname, cquantity, cprice, cfinal_price, ccode)
// VALUES ('$cname', '$cquantity', '$cprice',   '$cfinalprice', '$ccode')";

// if ($conn->query($sql) === TRUE) {
//     //  echo "New record created successfully";
//    // header('Location:home.php');
// } else {
//     echo "Error: " . $sql . "<br>" . $conn->error;
// }

// $conn->close();