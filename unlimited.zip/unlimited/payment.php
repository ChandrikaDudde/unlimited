<?php
session_start();


require_once("dbcontroller.php");
$db_handle = new DBController();
if (!empty($_GET["action"])) {
    switch ($_GET["action"]) {
        case "add":
            if (!empty($_POST["quantity"])) {
                $productByCode = $db_handle->runQuery("SELECT * FROM adddata WHERE code='" . $_GET["code"] . "'");
                $itemArray = array($productByCode[0]["code"] => array('name' => $productByCode[0]["pname"], 'code' => $productByCode[0]["code"], 'quantity' => $_POST["quantity"], 'price' => $productByCode[0]["pprice"], 'image' => $productByCode[0]["image"]));

                if (!empty($_SESSION["cart_item"])) {
                    if (in_array($productByCode[0]["code"], array_keys($_SESSION["cart_item"]))) {
                        foreach ($_SESSION["cart_item"] as $k => $v) {
                            if ($productByCode[0]["code"] == $k) {
                                if (empty($_SESSION["cart_item"][$k]["quantity"])) {
                                    $_SESSION["cart_item"][$k]["quantity"] = 0;
                                }
                                $_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
                            }
                        }
                    } else {
                        $_SESSION["cart_item"] = array_merge($_SESSION["cart_item"], $itemArray);
                    }
                } else {
                    $_SESSION["cart_item"] = $itemArray;
                }
            }
            break;
        case "remove":
            if (!empty($_SESSION["cart_item"])) {
                foreach ($_SESSION["cart_item"] as $k => $v) {
                    if ($_GET["code"] == $k)
                        unset($_SESSION["cart_item"][$k]);
                    if (empty($_SESSION["cart_item"]))
                        unset($_SESSION["cart_item"]);
                }
            }
            break;
        case "empty":
            unset($_SESSION["cart_item"]);
            break;
    }
}
?>
<!doctype html>
<html lang="zxx">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Unlimited</title>
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
    <!-- Template CSS -->
    <link href="//fonts.googleapis.com/css?family=Oswald:300,400,500,600&display=swap" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,900&display=swap" rel="stylesheet">
    <!-- Template CSS -->
    <link rel="stylesheet" href="style.css">

    <style>
        .modal-dialog {
            max-width: 999px;
            margin: 1.75rem auto;
        }
    </style>
</head>

<body>
    <section class="w3l-banner-slider-main inner-pagehny">
        <div class="breadcrumb-infhny">

            <div class="top-header-content">

                <header class="tophny-header">
                    <div class="container-fluid">
                        <div class="top-right-strip row">
                            <!--/left-->
                            <div class="top-hny-left-content col-lg-6 pl-lg-0">

                            </div>
                            <!--//left-->
                            <!--/right-->
                            <ul class="top-hnt-right-content col-lg-6">

                                <li class="transmitvcart galssescart2 cart cart box_1">

                                    <button class="top_transmitv_cart" data-toggle="modal" data-target="#myModal">
                                        My Cart
                                        <span class="fa fa-shopping-cart"></span>
                                    </button>

                                </li>
                            </ul>

                        </div>
                    </div>
                    <!--/nav-->
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <div class="container-fluid serarc-fluid">
                            <a class="navbar-brand" href="index.html">
                                UN<span class="lohny">L</span>imited</a>
                            <!-- if logo is image enable this   
                    <a class="navbar-brand" href="#index.html">
                      <img src="image-path" alt="Your logo" title="Your logo" style="height:35px;" />
                    </a> -->
                            <!--/search-right-->
                            <div class="search-right">

                                <a href="#search" title="search"><span class="fa fa-search mr-2" aria-hidden="true"></span>
                                    <span class="search-text">Search here</span></a>
                                <!-- search popup -->


                                <div id="search" class="pop-overlay">
                                    <div class="popup">

                                        <form action="#" method="post" class="search-box">
                                            <input type="search" placeholder="Keyword" name="search" required="required" autofocus="">
                                            <button type="submit" class="btn">Search</button>
                                        </form>

                                    </div>

                                    <a class="close" href="#">×</a>
                                </div>
                                <!-- /search popup -->
                            </div>
                            <!--//search-right-->
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon fa fa-bars"> </span>
                            </button>

                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <ul class="navbar-nav ml-auto">



                                    <li class="nav-item">
                                        <a class="nav-link" href="home.php">Home</a>
                                    </li>


                                    <li class="nav-item">
                                        <a class="nav-link" href="myorders.php">My Orders</a>
                                    </li>


                                    <li class="nav-item">
                                        <a class="nav-link" href="index.html">Logout</a>
                                    </li>
                                </ul>

                            </div>
                        </div>
                    </nav>
                    <!--//nav-->
                </header>
                <div class="breadcrumb-contentnhy">
                    <div class="container">
                        <nav aria-label="breadcrumb">
                            <h2 class="hny-title text-center">Payment</h2>

                        </nav>
                    </div>
                </div>
            </div>
        </div>

    </section>





    <div class="container" style="background: #fff;padding-top:30px;    padding-bottom: 2rem !important;max-width:100%">

        <div class="row">
            <div class="col-md-12">

                <div id="shopping-cart">


                    <!-- Modal -->
                    <div class="modal fade" id="myModal" role="dialog">
                        <div class="modal-dialog">

                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">

                                    <h4 class="modal-title">Cart Items</h4>
                                </div>
                                <div class="modal-body">



                                    <a id="btnEmpty" href="home.php?action=empty">Empty Cart</a>
                                    <?php
                                    if (isset($_SESSION["cart_item"])) {
                                        $total_quantity = 0;
                                        $total_price = 0;
                                    ?>
                                        <table class="tbl-cart" cellpadding="10" cellspacing="1">
                                            <tbody>



                                                <tr>
                                                    <th style="text-align:left;">Name</th>
                                                    <th style="text-align:left;">Code</th>
                                                    <th style="text-align:right;" width="5%">Quantity</th>
                                                    <th style="text-align:right;" width="10%">Unit Price</th>
                                                    <th style="text-align:right;" width="10%">Price</th>
                                                    <th style="text-align:center;" width="5%">Remove</th>
                                                </tr>


                                                <?php
                                                foreach ($_SESSION["cart_item"] as $item) {
                                                    $item_price = $item["quantity"] * $item["price"];
                                                ?>
                                                    <form method="POST" action="checkout.php">
                                                        <tr>
                                                            <td><img style="width:50px" src="<?php echo $item["image"]; ?>" class="cart-item-image" />

                                                                <input type="text" value=" <?php echo $item["name"];  ?>" style="border:none" name="cname[]" readonly>

                                                            </td>
                                                            <td>
                                                                <input type="text" value="<?php echo $item["code"]; ?>" class="form-control" name="ccode[]" readonly>
                                                            </td>
                                                            <td style="text-align:right;">
                                                                <input type="text" value="<?php echo $item["quantity"]; ?>" class="form-control" name="cquantity[]" readonly>
                                                            </td>
                                                            <td style="text-align:right;">
                                                                <input type="text" value="<?php echo "$ " . $item["price"]; ?>" class="form-control" name="cprice[]" readonly>
                                                            </td>
                                                            <td style="text-align:right;">
                                                                <input type="text" value="<?php echo "$ " . number_format($item_price, 2); ?>" style="margin-right:100px" class="form-control" name="cfinalprice[]" readonly>

                                                            </td>

                                                            <td style="text-align:center;"><a href="home.php?action=remove&code=<?php echo $item["code"]; ?>" class="btnRemoveAction"><img src="images/icon-delete.png" alt="Remove Item" /></a></td>
                                                        </tr>


                                                    <?php
                                                    $total_quantity += $item["quantity"];
                                                    $total_price += ($item["price"] * $item["quantity"]);
                                                }
                                                    ?>

                                                    <button id="btncheckout" type="submit" name="checkout_submit">Checkout</button>

                                                    </form>
                                                    <tr>
                                                        <td colspan="2" align="right">Total:</td>
                                                        <td align="right"><?php echo $total_quantity; ?></td>
                                                        <td align="right" colspan="2"><strong><?php echo "$ " . number_format($total_price, 2); ?></strong></td>
                                                        <td></td>
                                                    </tr>
                                            </tbody>
                                        </table>
                                    <?php
                                    } else {
                                    ?>
                                        <div class="no-records">Your Cart is Empty</div>
                                    <?php
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                        </div>

                    </div>
                </div>








            </div>

        </div>
    </div>






    <div class="container">
        <div class="row">
            <div class="col-md-6">

                <h2 style="text-align:center;padding-bottom:10px;">My Orders</h2>

                <?php

                include "config.php";

                $sql = "SELECT * FROM cart  ORDER BY cid DESC  LIMIT 1   ";


                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "


                            <table class='table table-stripped'>
                                <tr>
                                    <th>Product Name:</th>
                                     
                                    <td>   " . $row["cname"] . "  </td>
                                    
                                </tr>
                                <tr>
                                    <th> Product Price </th>
                                    <td>   " . $row["cprice"] . "  </td>
                                </tr>
                                <tr>
                                    <th> Product Quantity </th>
                                    <td>   " . $row["cquantity"] . "  </td>
                                </tr>
                                <tr>
                                    <th> Final Price</th>
                                    <td>   " . $row["cfinal_price"] . "  </td>
                                </tr>
                                <tr>
                                    <td></td>
                                </tr>
                             </table>



                        
                        
                        
                        ";
                    }
                } else {
                    echo "0 results";
                }
                $conn->close();
                ?>

            </div>

            <div class="col-md-6">

                <form method="POST" action="card.php">
                    <div class="form-group">
                        <label for="cardno">Enter Card Number</label>
                        <input type="number" class="form-control" name="cardno" id="cardno" required>
                    </div>

                    <div class="form-group">
                        <label for="name">Enter Name on the card</label>
                        <input type="text " class="form-control" name="name" id="name" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="cvv">Enter CVV</label>
                                <input type="number" class="form-control" name="cvv" id="cvv" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="expiry">Enter Expiry Date</label>
                                <input type="number" class="form-control" name="expiry" id="expiry" required>
                            </div>

                        </div>
                    </div>

                    <button class="btn btn-success form-control" type="submit" name="submit">Initiate Payment</button>
                </form>
            </div>
        </div>
    </div>







    <div class="container">

        <div class="row">
            <div class="col-md-12">

                <div id="shopping-cart">


                    <!-- Modal -->
                    <div class="modal fade" id="myModal" role="dialog">
                        <div class="modal-dialog modal-lg">

                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">

                                    <h4 class="modal-title">Cart Items</h4>
                                </div>
                                <div class="modal-body">


                                    <a id="btnEmpty" href="home.php?action=empty">Empty Cart</a>

                                    <?php
                                    if (isset($_SESSION["cart_item"])) {
                                        $total_quantity = 0;
                                        $total_price = 0;
                                    ?>
                                        <table class="tbl-cart" cellpadding="10" cellspacing="1">
                                            <tbody>
                                                <tr>
                                                    <th style="text-align:left;">Name</th>
                                                    <th style="text-align:left;">Code</th>
                                                    <th style="text-align:right;" width="5%">Quantity</th>
                                                    <th style="text-align:right;" width="10%">Unit Price</th>
                                                    <th style="text-align:right;" width="10%">Price</th>
                                                    <th style="text-align:center;" width="5%">Remove</th>
                                                </tr>
                                                <?php
                                                foreach ($_SESSION["cart_item"] as $item) {
                                                    $item_price = $item["quantity"] * $item["price"];
                                                ?>


                                                    <form>
                                                        <tr>
                                                            <td><img style="height:50px" src="<?php echo $item["image"]; ?>" class="cart-item-image" /><?php echo $item["name"]; ?></td>
                                                            <td><?php echo $item["code"]; ?></td>
                                                            <td style="text-align:right;"><?php echo $item["quantity"]; ?></td>
                                                            <td style="text-align:right;"><?php echo "$ " . $item["price"]; ?></td>
                                                            <td style="text-align:right;"><?php echo "$ " . number_format($item_price, 2); ?></td>
                                                            <td style="text-align:right;"><?php echo "$ " . number_format($item_price, 2); ?></td>
                                                            <td style="text-align:center;"><a href="home.php?action=remove&code=<?php echo $item["code"]; ?>" class="btnRemoveAction">
                                                                    <img src="images/icon-delete.png" alt="Remove Item" /></a></td>
                                                            <button class="btn btn-success" type="submit">Checkout</button>

                                                        </tr>



                                                    </form>


                                                <?php
                                                    $total_quantity += $item["quantity"];
                                                    $total_price += ($item["price"] * $item["quantity"]);
                                                }
                                                ?>

                                                <tr>
                                                    <td colspan="2" align="right">Total:</td>
                                                    <td align="right"><?php echo $total_quantity; ?></td>
                                                    <td align="right" colspan="2"><strong><?php echo "$ " . number_format($total_price, 2); ?></strong></td>
                                                    <td></td>
                                                </tr>


                                            </tbody>
                                        </table>
                                    <?php
                                    } else {
                                    ?>
                                        <div class="no-records">Your Cart is Empty</div>
                                    <?php
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                        </div>

                    </div>
                </div>










            </div>

        </div>
    </div>


    <div class="container" style="background: #232020;padding-top:30px;    padding-bottom: 2rem !important;max-width:100%">

        <div class="row">
            <div class="col-md-12">
                <p style="text-align:center;color:white">© 2020 Unlimited. All rights reserved. Design by <a style="color:white" href="index.html">
                        Unlimited Team</a>
                </p>
            </div>
        </div>
    </div>




</body>

</html>

<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/jquery-2.1.4.min.js"></script>
<!--/login-->
<script>
    $(document).ready(function() {
        $(".button-log a").click(function() {
            $(".overlay-login").fadeToggle(200);
            $(this).toggleClass('btn-open').toggleClass('btn-close');
        });
    });
    $('.overlay-close1').on('click', function() {
        $(".overlay-login").fadeToggle(200);
        $(".button-log a").toggleClass('btn-open').toggleClass('btn-close');
        open = false;
    });
</script>
<!--//login-->
<script>
    // optional
    $('#customerhnyCarousel').carousel({
        interval: 5000
    });
</script>
<!-- cart-js -->
<script src="assets/js/minicart.js"></script>
<script>
    transmitv.render();

    transmitv.cart.on('transmitv_checkout', function(evt) {
        var items, len, i;

        if (this.subtotal() > 0) {
            items = this.items();

            for (i = 0, len = items.length; i < len; i++) {}
        }
    });
</script>
<!-- //cart-js -->

<!-- disable body scroll which navbar is in active -->

<script>
    $(function() {
        $('.navbar-toggler').click(function() {
            $('body').toggleClass('noscroll');
        })
    });
</script>
<!-- disable body scroll which navbar is in active -->
<script src="assets/js/bootstrap.min.js"></script>