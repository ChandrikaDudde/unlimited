<?php
 
 include 'config.php';

$row_data = array();
foreach($_POST['cname'] as $row=>$name) {
// $issuedate=('Y-m-d');
// $issuetime=('h:i:s');


    // $name=($Name);
    // $id= mysqli_real_escape_string($_POST['cname'][$row]);
    // $icno= ($_POST['icno'][$row]);
    // $route= ($_POST['route'][$row]);
    // $price= ($_POST['price'][$row]);
    // $date= ($_POST['date'][$row]);
    // $time= ($_POST['time'][$row]);
    // $username= ($_POST['username'][$row]);
    // $pax= ($_POST['pax'][$row]);
    // $paxcur = $pax - $row;


    // $cname = mysqli_real_escape_string ($_POST['cname']);
    $cname = $_POST['cname'];
    $ccode = $_POST['ccode'];
    $cquantity = $_POST['cquantity'];
    $cprice = $_POST['cprice'];
    $cfinalprice = $_POST['cfinalprice'];





$row_data[] = "(',', '$cname', '$ccode', '$cquantity', '$cprice', '$cfinalprice' )";
}
if (!empty($row_data)) {
    $query = 'INSERT INTO cart(id, cname, ccode, cquantity, cprice, cfinal_price ) VALUES '.implode(',', $row_data);

if (mysqli_query($conn, $query))
    echo 'Successful inserts: ' . $query;
else
    echo 'query failed';
}


?>