<?php
session_start();


require_once("dbcontroller.php");
$db_handle = new DBController();
if (!empty($_GET["action"])) {
    switch ($_GET["action"]) {
        case "add":
            if (!empty($_POST["quantity"])) {
                $productByCode = $db_handle->runQuery("SELECT * FROM adddata WHERE code='" . $_GET["code"] . "'");
                $itemArray = array($productByCode[0]["code"] => array('name' => $productByCode[0]["pname"], 'code' => $productByCode[0]["code"], 'quantity' => $_POST["quantity"], 'price' => $productByCode[0]["pprice"], 'image' => $productByCode[0]["image"]));

                if (!empty($_SESSION["cart_item"])) {
                    if (in_array($productByCode[0]["code"], array_keys($_SESSION["cart_item"]))) {
                        foreach ($_SESSION["cart_item"] as $k => $v) {
                            if ($productByCode[0]["code"] == $k) {
                                if (empty($_SESSION["cart_item"][$k]["quantity"])) {
                                    $_SESSION["cart_item"][$k]["quantity"] = 0;
                                }
                                $_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
                            }
                        }
                    } else {
                        $_SESSION["cart_item"] = array_merge($_SESSION["cart_item"], $itemArray);
                    }
                } else {
                    $_SESSION["cart_item"] = $itemArray;
                }
            }
            break;
        case "remove":
            if (!empty($_SESSION["cart_item"])) {
                foreach ($_SESSION["cart_item"] as $k => $v) {
                    if ($_GET["code"] == $k)
                        unset($_SESSION["cart_item"][$k]);
                    if (empty($_SESSION["cart_item"]))
                        unset($_SESSION["cart_item"]);
                }
            }
            break;
        case "empty":
            unset($_SESSION["cart_item"]);
            break;
    }
}
?>
<!doctype html>
<html lang="zxx">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Unlimited</title>
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
    <!-- Template CSS -->
    <link href="//fonts.googleapis.com/css?family=Oswald:300,400,500,600&display=swap" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,900&display=swap" rel="stylesheet">
    <!-- Template CSS -->
    <link rel="stylesheet" href="style.css">

    <style>
        .modal-dialog {
            max-width: 999px;
            margin: 1.75rem auto;
        }
    </style>
</head>

<body>
    <section class="w3l-banner-slider-main inner-pagehny">
        <div class="breadcrumb-infhny">

            <div class="top-header-content">

                <header class="tophny-header">
                    <div class="container-fluid">
                        <div class="top-right-strip row">
                            <!--/left-->
                            <div class="top-hny-left-content col-lg-6 pl-lg-0">

                            </div>
                            <!--//left-->
                            <!--/right-->
                            <ul class="top-hnt-right-content col-lg-6">

                                <li class="transmitvcart galssescart2 cart cart box_1">

                                    <button class="top_transmitv_cart" data-toggle="modal" data-target="#myModal">
                                        My Cart
                                        <span class="fa fa-shopping-cart"></span>
                                    </button>

                                </li>
                            </ul>

                        </div>
                    </div>
                    <!--/nav-->
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <div class="container-fluid serarc-fluid">
                            <a class="navbar-brand" href="index.html">
                                UN<span class="lohny">L</span>imited</a>
                            <!-- if logo is image enable this   
                    <a class="navbar-brand" href="#index.html">
                      <img src="image-path" alt="Your logo" title="Your logo" style="height:35px;" />
                    </a> -->
                            <!--/search-right-->
                            <div class="search-right">

                                <a href="#search" title="search"><span class="fa fa-search mr-2" aria-hidden="true"></span>
                                    <span class="search-text">Search here</span></a>
                                <!-- search popup -->


                                <div id="search" class="pop-overlay">
                                    <div class="popup">

                                        <form action="search.php" class="search-box">
                                            <input type="search" id="myInput" placeholder="Keyword" name="search" required="required" autofocus="">
                                            <button type="submit" class="btn" id="myInput">Search</button>


                                        </form>

                                    </div>

                                    <a class="close" href="#">×</a>
                                </div>
                                <!-- /search popup -->
                            </div>
                            <!--//search-right-->
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon fa fa-bars"> </span>
                            </button>

                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <ul class="navbar-nav ml-auto">



                                    <li class="nav-item">
                                        <a class="nav-link" href="home.php">Home</a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link" href="#clothing">clothing</a>
                                    </li>


                                    <li class="nav-item">
                                        <a class="nav-link" href="#mobiles">Mobiles</a>
                                    </li>



                                    <li class="nav-item">
                                        <a class="nav-link" href="#mens">Mens</a>
                                    </li>



                                    <li class="nav-item">
                                        <a class="nav-link" href="#shoes">Shoes</a>
                                    </li>


                                    <li class="nav-item">
                                        <a class="nav-link" href="myorders.php">My Orders</a>
                                    </li>


                                    <li class="nav-item">
                                        <a class="nav-link" href="index.html">Logout</a>
                                    </li>
                                </ul>

                            </div>
                        </div>
                    </nav>
                    <!--//nav-->
                </header>

            </div>
        </div>
    </section>





    <div class="container" style="background: #fff;padding-top:30px;    padding-bottom: 2rem !important;max-width:100%">

        <div class="row">
            <div class="col-md-12">

                <div id="shopping-cart">


                    <!-- Modal -->
                    <div class="modal fade" id="myModal" role="dialog">
                        <div class="modal-dialog">

                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">

                                    <h4 class="modal-title">Cart Items</h4>
                                </div>
                                <div class="modal-body">



                                    <a id="btnEmpty" href="home.php?action=empty">Empty Cart</a>
                                    <?php
                                    if (isset($_SESSION["cart_item"])) {
                                        $total_quantity = 0;
                                        $total_price = 0;
                                    ?>
                                        <table class="tbl-cart" cellpadding="10" cellspacing="1">
                                            <tbody>



                                                <tr>
                                                    <th style="text-align:left;">Name</th>
                                                    <th style="text-align:left;">Code</th>
                                                    <th style="text-align:right;" width="5%">Quantity</th>
                                                    <th style="text-align:right;" width="10%">Unit Price</th>
                                                    <th style="text-align:right;" width="10%">Price</th>
                                                    <th style="text-align:center;" width="5%">Remove</th>
                                                </tr>


                                                <?php
                                                foreach ($_SESSION["cart_item"] as $item) {
                                                    $item_price = $item["quantity"] * $item["price"];
                                                ?>
                                                    <form method="POST" action="checkout.php">
                                                        <tr>
                                                            <td><img style="width:50px" src="<?php echo $item["image"]; ?>" class="cart-item-image" />

                                                                <input type="text" value=" <?php echo $item["name"];  ?>" style="border:none" name="cname[]" readonly>

                                                            </td>
                                                            <td>
                                                                <input type="text" value="<?php echo $item["code"]; ?>" class="form-control" name="ccode[]" readonly>
                                                            </td>
                                                            <td style="text-align:right;">
                                                                <input type="text" value="<?php echo $item["quantity"]; ?>" class="form-control" name="cquantity[]" readonly>
                                                            </td>
                                                            <td style="text-align:right;">
                                                                <input type="text" value="<?php echo "$ " . $item["price"]; ?>" class="form-control" name="cprice[]" readonly>
                                                            </td>
                                                            <td style="text-align:right;">
                                                                <input type="text" value="<?php echo "$ " . number_format($item_price, 2); ?>" style="margin-right:100px" class="form-control" name="cfinalprice[]" readonly>

                                                            </td>

                                                            <td style="text-align:center;"><a href="home.php?action=remove&code=<?php echo $item["code"]; ?>" class="btnRemoveAction"><img src="images/icon-delete.png" alt="Remove Item" /></a></td>
                                                        </tr>


                                                    <?php
                                                    $total_quantity += $item["quantity"];
                                                    $total_price += ($item["price"] * $item["quantity"]);
                                                }
                                                    ?>

                                                    <button id="btncheckout" type="submit" name="checkout_submit">Checkout</button>

                                                    </form>
                                                    <tr>
                                                        <td colspan="2" align="right">Total:</td>
                                                        <td align="right"><?php echo $total_quantity; ?></td>
                                                        <td align="right" colspan="2"><strong><?php echo "$ " . number_format($total_price, 2); ?></strong></td>
                                                        <td></td>
                                                    </tr>
                                            </tbody>
                                        </table>
                                    <?php
                                    } else {
                                    ?>
                                        <div class="no-records">Your Cart is Empty</div>
                                    <?php
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                        </div>

                    </div>
                </div>








            </div>

        </div>
    </div>


    <div id="myDIV">

        <div class="container">
            <div class="row">

                <div id="product-grid">
                    <div class="txt-heading" id="clothing">
                        <h1>Searched Products</h1>
                    </div>
                    <?php

                    $s = $_GET['search'];

                    
                    $product_array = $db_handle->runQuery("SELECT * FROM adddata WHERE pname='$s'  ");
                    if (!empty($product_array)) {
                        foreach ($product_array as $key => $value) {
                    ?>
                            <div class="product-item">
                                <form method="post" action="home.php?action=add&code=<?php echo $product_array[$key]["code"]; ?>">
                                    <div class="product-image"><img style="width:100%;height:150px" src="<?php echo $product_array[$key]["image"]; ?>"></div>
                                    <div class="product-tile-footer">
                                        <div class="product-title"><?php echo $product_array[$key]["pname"]; ?></div>
                                        <div class="product-price"><?php echo "$" . $product_array[$key]["pprice"]; ?></div>
                                        <div class="cart-action"><input type="text" class="product-quantity" name="quantity" value="1" size="2" />
                                            <input type="submit" value="Add to Cart" class="btnAddAction" />
                                        </div>
                                    </div>
                                </form>
                            </div>
                    <?php
                        }
                    }
                    ?>
                </div>

            </div>

        </div>



    </div>



    <div class="container" style="background: #232020;padding-top:30px;    padding-bottom: 2rem !important;max-width:100%">

        <div class="row">
            <div class="col-md-12">
                <p style="text-align:center;color:white">© 2020 Unlimited. All rights reserved. Design by <a style="color:white" href="index.html">
                        Unlimited Team</a>
                </p>
            </div>
        </div>
    </div>

    <!-- search field -->

    <script>
        $(document).ready(function() {
            $("#myInput").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#myDIV *").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
    </script>

</body>

</html>

<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/jquery-2.1.4.min.js"></script>
<!--/login-->
<script>
    $(document).ready(function() {
        $(".button-log a").click(function() {
            $(".overlay-login").fadeToggle(200);
            $(this).toggleClass('btn-open').toggleClass('btn-close');
        });
    });
    $('.overlay-close1').on('click', function() {
        $(".overlay-login").fadeToggle(200);
        $(".button-log a").toggleClass('btn-open').toggleClass('btn-close');
        open = false;
    });
</script>
<!--//login-->
<script>
    // optional
    $('#customerhnyCarousel').carousel({
        interval: 5000
    });
</script>
<!-- cart-js -->
<script src="assets/js/minicart.js"></script>
<script>
    transmitv.render();

    transmitv.cart.on('transmitv_checkout', function(evt) {
        var items, len, i;

        if (this.subtotal() > 0) {
            items = this.items();

            for (i = 0, len = items.length; i < len; i++) {}
        }
    });
</script>
<!-- //cart-js -->

<!-- disable body scroll which navbar is in active -->

<script>
    $(function() {
        $('.navbar-toggler').click(function() {
            $('body').toggleClass('noscroll');
        })
    });
</script>
<!-- disable body scroll which navbar is in active -->
<script src="assets/js/bootstrap.min.js"></script>