<?php
include "config.php";


$pname = $_POST['pname'];
$pprice = $_POST['pprice'];
$pdesc = $_POST['pdesc']; 
$cate= $_POST['cate'];
$code = $_POST['code'];

// echo $title;
// echo $cate;
// echo $desc;

$target_path = "images/";

$target_path = $target_path . basename($_FILES['file']['name']);

if (move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {
    $sql = "INSERT INTO  adddata (pname, pprice, pdesc, cate, code, image)
            values('$pname','$pprice','$pdesc','$cate', '$code',' $target_path' )";

    if ($conn->query($sql) === TRUE) {
        // echo "New record created successfully";
        header('Location:add_data.php');
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
} 










?>