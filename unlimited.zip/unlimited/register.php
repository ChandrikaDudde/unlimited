<?php
include "config.php";


$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address']; 
$pass = $_POST['pass'];



// echo $title;
// echo $cate;
// echo $desc;

$sql = "INSERT INTO register (name, email, phone, address, pass)
VALUES ('$name', '$email', '$phone',   '$address', '$pass')";

if ($conn->query($sql) === TRUE) {
    //  echo "New record created successfully";
    header('Location:index.html');
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();