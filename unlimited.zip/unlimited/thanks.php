<?php
session_start();


?>
<!doctype html>
<html lang="zxx">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Unlimited</title>
  <!-- Template CSS -->
  <link rel="stylesheet" href="assets/css/style-starter.css">
  <!-- Template CSS -->
  <link href="//fonts.googleapis.com/css?family=Oswald:300,400,500,600&display=swap" rel="stylesheet">
  <link href="//fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,900&display=swap" rel="stylesheet">
  <!-- Template CSS -->
  <link rel="stylesheet" href="style.css">

  <style>
    .modal-dialog {
      max-width: 999px;
      margin: 1.75rem auto;
    }

    .w3l-banner-slider-main.inner-pagehny .breadcrumb-infhny {
      background: #000;
      background-size: cover;
      -webkit-background-size: cover;
      -o-background-size: cover;
      -ms-background-size: cover;
      -moz-background-size: cover;
      z-index: 9;
      position: relative;
      min-height: 8em;
    }

    img.center {
      display: block;
      margin: 0 auto;
      width: 700px;
      height: 500px;
      padding:20px;
    }
  </style>
</head>

<body>
  <section class="w3l-banner-slider-main inner-pagehny">
    <div class="breadcrumb-infhny">

      <div class="top-header-content">

        <header class="tophny-header">
          <div class="container-fluid">
            <div class="top-right-strip row">
              <!--/left-->
              <div class="top-hny-left-content col-lg-6 pl-lg-0">

              </div>
              <!--//left-->
              <!--/right-->
              <ul class="top-hnt-right-content col-lg-6">

                <li class="transmitvcart galssescart2 cart cart box_1">

                  <button class="top_transmitv_cart" data-toggle="modal" data-target="#myModal">
                    My Cart
                    <span class="fa fa-shopping-cart"></span>
                  </button>

                </li>
              </ul>

            </div>
          </div>
          <!--/nav-->
          <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid serarc-fluid">
              <a class="navbar-brand" href="index.html">
                UN<span class="lohny">L</span>imited</a>
              <!-- if logo is image enable this   
                    <a class="navbar-brand" href="#index.html">
                      <img src="image-path" alt="Your logo" title="Your logo" style="height:35px;" />
                    </a> -->
              <!--/search-right-->
              <div class="search-right">

                <a href="#search" title="search"><span class="fa fa-search mr-2" aria-hidden="true"></span>
                  <span class="search-text">Search here</span></a>
                <!-- search popup -->


                <div id="search" class="pop-overlay">
                  <div class="popup">

                    <form action="#" method="post" class="search-box">
                      <input type="search" placeholder="Keyword" name="search" required="required" autofocus="">
                      <button type="submit" class="btn">Search</button>
                    </form>

                  </div>

                  <a class="close" href="#">×</a>
                </div>
                <!-- /search popup -->
              </div>
              <!--//search-right-->
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon fa fa-bars"> </span>
              </button>

              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">



                  <li class="nav-item">
                    <a class="nav-link" href="home.php">Home</a>
                  </li>


                  <li class="nav-item">
                    <a class="nav-link" href="myorders.php">My Orders</a>
                  </li>


                  <li class="nav-item">
                    <a class="nav-link" href="index.html">Logout</a>
                  </li>
                </ul>

              </div>
            </div>
          </nav>
          <!--//nav-->
        </header>

      </div>
    </div>
  </section>










  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <img src="assets/images/thanks.jpg" alt="thank"  class="center">
        <!-- <button class="btn btn-success">Home</button> -->
      </div>
    </div>
  </div>













  <div class="container" style="background: #232020;padding-top:30px;    padding-bottom: 2rem !important;max-width:100%">

    <div class="row">
      <div class="col-md-12">
        <p style="text-align:center;color:white">© 2020 Unlimited. All rights reserved. Design by <a style="color:white" href="index.html">
            Unlimited Team</a>
        </p>
      </div>
    </div>
  </div>




</body>

</html>

<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/jquery-2.1.4.min.js"></script>
<!--/login-->
<script>
  $(document).ready(function() {
    $(".button-log a").click(function() {
      $(".overlay-login").fadeToggle(200);
      $(this).toggleClass('btn-open').toggleClass('btn-close');
    });
  });
  $('.overlay-close1').on('click', function() {
    $(".overlay-login").fadeToggle(200);
    $(".button-log a").toggleClass('btn-open').toggleClass('btn-close');
    open = false;
  });
</script>
<!--//login-->
<script>
  // optional
  $('#customerhnyCarousel').carousel({
    interval: 5000
  });
</script>
<!-- cart-js -->
<script src="assets/js/minicart.js"></script>
<script>
  transmitv.render();

  transmitv.cart.on('transmitv_checkout', function(evt) {
    var items, len, i;

    if (this.subtotal() > 0) {
      items = this.items();

      for (i = 0, len = items.length; i < len; i++) {}
    }
  });
</script>
<!-- //cart-js -->

<!-- disable body scroll which navbar is in active -->

<script>
  $(function() {
    $('.navbar-toggler').click(function() {
      $('body').toggleClass('noscroll');
    })
  });
</script>
<!-- disable body scroll which navbar is in active -->
<script src="assets/js/bootstrap.min.js"></script>