<?php


session_start();
$uname = $_SESSION['uname'];


include "config.php";


$cardno = $_POST['cardno'];
$name = $_POST['name'];
$cvv = $_POST['cvv'];
$expiry = $_POST['expiry']; 
 


 

$sql = "INSERT INTO card (cardno, name, cvv, expiry, uname)
VALUES ('$cardno', '$name', '$cvv', '$expiry', '$uname')";

if ($conn->query($sql) === TRUE) {
    //  echo "New record created successfully";
    header('Location:thanks.php');
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();